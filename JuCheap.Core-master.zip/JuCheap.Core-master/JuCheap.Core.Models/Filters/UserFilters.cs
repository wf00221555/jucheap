﻿namespace JuCheap.Core.Models.Filters
{
    /// <summary>
    /// 用户搜索过滤器
    /// </summary>
    public class UserFilters : BaseFilter
    {
        
    }
}
