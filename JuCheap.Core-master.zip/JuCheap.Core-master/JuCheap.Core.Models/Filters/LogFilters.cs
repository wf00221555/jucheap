﻿namespace JuCheap.Core.Models.Filters
{
    /// <summary>
    /// 日志搜索过滤器
    /// </summary>
    public class LogFilters : BaseFilter
    {
        
    }
}
