﻿namespace JuCheap.Core.Infrastructure.Utilities
{
    public static class Constants
    {
        public static class Log4net
        {
            /// <summary>
            /// RepositoryName
            /// </summary>
            public static string RepositoryName = "JuCheapCoreRepository";

            /// <summary>
            /// LoggerName
            /// </summary>
            public static string LoggerName = "SystemError";
        }
    }
}
