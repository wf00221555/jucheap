﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SHRMS
{
    class GlobalData
    {
        public static string username = string.Empty;
        public static string connectionStr = "server=127.0.0.1;user=root;database=csharp_hrms;port=3306;password=mysql;";
    }
}
