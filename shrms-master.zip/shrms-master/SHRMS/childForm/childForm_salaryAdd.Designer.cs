﻿namespace SHRMS.childForm
{
    partial class childForm_salaryAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_top = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_center = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.numericUpDown_yingfa = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_shuilv = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_butie = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_realsalary = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_jiabanfei = new System.Windows.Forms.NumericUpDown();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.numericUpDown_yingkou = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_jiangjin = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_baseSalary = new System.Windows.Forms.NumericUpDown();
            this.label_role = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label_dept = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label_empNo = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox_str = new System.Windows.Forms.TextBox();
            this.label_query = new System.Windows.Forms.Label();
            this.btn_query = new System.Windows.Forms.Button();
            this.panel_bottom = new System.Windows.Forms.Panel();
            this.dataGridView_salary = new System.Windows.Forms.DataGridView();
            this.panel_top.SuspendLayout();
            this.panel_center.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_yingfa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_shuilv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_butie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_realsalary)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_jiabanfei)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_yingkou)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_jiangjin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_baseSalary)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel_bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_salary)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_top
            // 
            this.panel_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(137)))), ((int)(((byte)(152)))));
            this.panel_top.Controls.Add(this.label1);
            this.panel_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_top.Location = new System.Drawing.Point(0, 0);
            this.panel_top.Name = "panel_top";
            this.panel_top.Size = new System.Drawing.Size(1060, 44);
            this.panel_top.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.LightGray;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "位置：薪资管理 > 录入薪资";
            // 
            // panel_center
            // 
            this.panel_center.Controls.Add(this.groupBox2);
            this.panel_center.Controls.Add(this.groupBox1);
            this.panel_center.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_center.Location = new System.Drawing.Point(0, 44);
            this.panel_center.Name = "panel_center";
            this.panel_center.Size = new System.Drawing.Size(1060, 311);
            this.panel_center.TabIndex = 7;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.numericUpDown_yingfa);
            this.groupBox2.Controls.Add(this.numericUpDown_shuilv);
            this.groupBox2.Controls.Add(this.numericUpDown_butie);
            this.groupBox2.Controls.Add(this.numericUpDown_realsalary);
            this.groupBox2.Controls.Add(this.numericUpDown_jiabanfei);
            this.groupBox2.Controls.Add(this.btn_cancel);
            this.groupBox2.Controls.Add(this.btn_update);
            this.groupBox2.Controls.Add(this.numericUpDown_yingkou);
            this.groupBox2.Controls.Add(this.numericUpDown_jiangjin);
            this.groupBox2.Controls.Add(this.numericUpDown_baseSalary);
            this.groupBox2.Controls.Add(this.label_role);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label_name);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label_dept);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label_empNo);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox2.Location = new System.Drawing.Point(12, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1036, 191);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "薪资信息";
            // 
            // numericUpDown_yingfa
            // 
            this.numericUpDown_yingfa.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_yingfa.Location = new System.Drawing.Point(779, 46);
            this.numericUpDown_yingfa.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.numericUpDown_yingfa.Name = "numericUpDown_yingfa";
            this.numericUpDown_yingfa.Size = new System.Drawing.Size(91, 29);
            this.numericUpDown_yingfa.TabIndex = 9;
            // 
            // numericUpDown_shuilv
            // 
            this.numericUpDown_shuilv.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_shuilv.Location = new System.Drawing.Point(779, 93);
            this.numericUpDown_shuilv.Name = "numericUpDown_shuilv";
            this.numericUpDown_shuilv.Size = new System.Drawing.Size(67, 29);
            this.numericUpDown_shuilv.TabIndex = 9;
            // 
            // numericUpDown_butie
            // 
            this.numericUpDown_butie.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_butie.Location = new System.Drawing.Point(523, 45);
            this.numericUpDown_butie.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.numericUpDown_butie.Name = "numericUpDown_butie";
            this.numericUpDown_butie.Size = new System.Drawing.Size(91, 29);
            this.numericUpDown_butie.TabIndex = 9;
            // 
            // numericUpDown_realsalary
            // 
            this.numericUpDown_realsalary.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_realsalary.Location = new System.Drawing.Point(779, 137);
            this.numericUpDown_realsalary.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.numericUpDown_realsalary.Name = "numericUpDown_realsalary";
            this.numericUpDown_realsalary.Size = new System.Drawing.Size(91, 29);
            this.numericUpDown_realsalary.TabIndex = 9;
            // 
            // numericUpDown_jiabanfei
            // 
            this.numericUpDown_jiabanfei.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_jiabanfei.Location = new System.Drawing.Point(523, 92);
            this.numericUpDown_jiabanfei.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.numericUpDown_jiabanfei.Name = "numericUpDown_jiabanfei";
            this.numericUpDown_jiabanfei.Size = new System.Drawing.Size(91, 29);
            this.numericUpDown_jiabanfei.TabIndex = 9;
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.btn_cancel.FlatAppearance.BorderSize = 0;
            this.btn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_cancel.ForeColor = System.Drawing.Color.White;
            this.btn_cancel.Location = new System.Drawing.Point(907, 47);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(122, 40);
            this.btn_cancel.TabIndex = 31;
            this.btn_cancel.Text = "取  消";
            this.btn_cancel.UseVisualStyleBackColor = false;
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(223)))), ((int)(((byte)(163)))));
            this.btn_update.FlatAppearance.BorderSize = 0;
            this.btn_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_update.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_update.ForeColor = System.Drawing.Color.White;
            this.btn_update.Location = new System.Drawing.Point(907, 123);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(122, 40);
            this.btn_update.TabIndex = 31;
            this.btn_update.Text = "确认录入";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // numericUpDown_yingkou
            // 
            this.numericUpDown_yingkou.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_yingkou.Location = new System.Drawing.Point(523, 136);
            this.numericUpDown_yingkou.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.numericUpDown_yingkou.Name = "numericUpDown_yingkou";
            this.numericUpDown_yingkou.Size = new System.Drawing.Size(91, 29);
            this.numericUpDown_yingkou.TabIndex = 9;
            // 
            // numericUpDown_jiangjin
            // 
            this.numericUpDown_jiangjin.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_jiangjin.Location = new System.Drawing.Point(273, 136);
            this.numericUpDown_jiangjin.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.numericUpDown_jiangjin.Name = "numericUpDown_jiangjin";
            this.numericUpDown_jiangjin.Size = new System.Drawing.Size(91, 29);
            this.numericUpDown_jiangjin.TabIndex = 9;
            // 
            // numericUpDown_baseSalary
            // 
            this.numericUpDown_baseSalary.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_baseSalary.Location = new System.Drawing.Point(273, 89);
            this.numericUpDown_baseSalary.Maximum = new decimal(new int[] {
            9999999,
            0,
            0,
            0});
            this.numericUpDown_baseSalary.Name = "numericUpDown_baseSalary";
            this.numericUpDown_baseSalary.Size = new System.Drawing.Size(91, 29);
            this.numericUpDown_baseSalary.TabIndex = 9;
            // 
            // label_role
            // 
            this.label_role.AutoSize = true;
            this.label_role.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_role.Location = new System.Drawing.Point(98, 138);
            this.label_role.Name = "label_role";
            this.label_role.Size = new System.Drawing.Size(57, 27);
            this.label_role.TabIndex = 8;
            this.label_role.Text = "×××";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(680, 140);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(107, 25);
            this.label23.TabIndex = 7;
            this.label23.Text = "实发工资：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(425, 139);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(107, 25);
            this.label17.TabIndex = 7;
            this.label17.Text = "应扣工资：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(205, 138);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 25);
            this.label11.TabIndex = 7;
            this.label11.Text = "奖  金：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(849, 94);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 27);
            this.label12.TabIndex = 8;
            this.label12.Text = "%";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_name.Location = new System.Drawing.Point(268, 44);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(57, 27);
            this.label_name.TabIndex = 8;
            this.label_name.Text = "×××";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(706, 93);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(81, 25);
            this.label21.TabIndex = 7;
            this.label21.Text = "税  率：";
            // 
            // label_dept
            // 
            this.label_dept.AutoSize = true;
            this.label_dept.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_dept.Location = new System.Drawing.Point(98, 95);
            this.label_dept.Name = "label_dept";
            this.label_dept.Size = new System.Drawing.Size(46, 21);
            this.label_dept.TabIndex = 8;
            this.label_dept.Text = "×××";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(443, 92);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 25);
            this.label15.TabIndex = 7;
            this.label15.Text = "加班费：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(9, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "员工职务：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(680, 47);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(107, 25);
            this.label20.TabIndex = 7;
            this.label20.Text = "应发工资：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(205, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 25);
            this.label8.TabIndex = 7;
            this.label8.Text = "底  薪：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(449, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 25);
            this.label14.TabIndex = 7;
            this.label14.Text = "补  贴：";
            // 
            // label_empNo
            // 
            this.label_empNo.AutoSize = true;
            this.label_empNo.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_empNo.Location = new System.Drawing.Point(98, 45);
            this.label_empNo.Name = "label_empNo";
            this.label_empNo.Size = new System.Drawing.Size(60, 27);
            this.label_empNo.TabIndex = 8;
            this.label_empNo.Text = "0000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(9, 93);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "所在部门：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(204, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "姓  名：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(9, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "员工编号：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox_str);
            this.groupBox1.Controls.Add(this.label_query);
            this.groupBox1.Controls.Add(this.btn_query);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox1.Location = new System.Drawing.Point(12, 203);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1036, 96);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "快速查找";
            // 
            // textBox_str
            // 
            this.textBox_str.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_str.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_str.Location = new System.Drawing.Point(719, 41);
            this.textBox_str.Name = "textBox_str";
            this.textBox_str.Size = new System.Drawing.Size(141, 26);
            this.textBox_str.TabIndex = 49;
            // 
            // label_query
            // 
            this.label_query.AutoSize = true;
            this.label_query.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_query.Location = new System.Drawing.Point(565, 41);
            this.label_query.Name = "label_query";
            this.label_query.Size = new System.Drawing.Size(150, 25);
            this.label_query.TabIndex = 51;
            this.label_query.Text = "按教师编号查询:";
            // 
            // btn_query
            // 
            this.btn_query.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.btn_query.FlatAppearance.BorderSize = 0;
            this.btn_query.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_query.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_query.ForeColor = System.Drawing.Color.White;
            this.btn_query.Location = new System.Drawing.Point(888, 33);
            this.btn_query.Name = "btn_query";
            this.btn_query.Size = new System.Drawing.Size(141, 40);
            this.btn_query.TabIndex = 31;
            this.btn_query.Text = "点击查询";
            this.btn_query.UseVisualStyleBackColor = false;
            this.btn_query.Click += new System.EventHandler(this.btn_query_Click);
            // 
            // panel_bottom
            // 
            this.panel_bottom.Controls.Add(this.dataGridView_salary);
            this.panel_bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_bottom.Location = new System.Drawing.Point(0, 355);
            this.panel_bottom.Name = "panel_bottom";
            this.panel_bottom.Size = new System.Drawing.Size(1060, 355);
            this.panel_bottom.TabIndex = 8;
            // 
            // dataGridView_salary
            // 
            this.dataGridView_salary.AllowUserToAddRows = false;
            this.dataGridView_salary.AllowUserToDeleteRows = false;
            this.dataGridView_salary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_salary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_salary.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_salary.Name = "dataGridView_salary";
            this.dataGridView_salary.ReadOnly = true;
            this.dataGridView_salary.RowTemplate.Height = 23;
            this.dataGridView_salary.Size = new System.Drawing.Size(1060, 355);
            this.dataGridView_salary.TabIndex = 0;
            this.dataGridView_salary.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_salary_CellClick);
            // 
            // childForm_salaryAdd
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1060, 710);
            this.Controls.Add(this.panel_bottom);
            this.Controls.Add(this.panel_center);
            this.Controls.Add(this.panel_top);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "childForm_salaryAdd";
            this.Text = "childForm_salaryAdd";
            this.panel_top.ResumeLayout(false);
            this.panel_top.PerformLayout();
            this.panel_center.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_yingfa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_shuilv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_butie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_realsalary)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_jiabanfei)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_yingkou)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_jiangjin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_baseSalary)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel_bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_salary)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_top;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_center;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label_role;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label_dept;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label_empNo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox_str;
        private System.Windows.Forms.Label label_query;
        private System.Windows.Forms.Button btn_query;
        private System.Windows.Forms.NumericUpDown numericUpDown_yingfa;
        private System.Windows.Forms.NumericUpDown numericUpDown_shuilv;
        private System.Windows.Forms.NumericUpDown numericUpDown_butie;
        private System.Windows.Forms.NumericUpDown numericUpDown_realsalary;
        private System.Windows.Forms.NumericUpDown numericUpDown_jiabanfei;
        private System.Windows.Forms.NumericUpDown numericUpDown_yingkou;
        private System.Windows.Forms.NumericUpDown numericUpDown_jiangjin;
        private System.Windows.Forms.NumericUpDown numericUpDown_baseSalary;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel_bottom;
        private System.Windows.Forms.DataGridView dataGridView_salary;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_update;
    }
}