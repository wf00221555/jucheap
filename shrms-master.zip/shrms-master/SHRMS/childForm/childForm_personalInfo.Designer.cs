﻿namespace SHRMS.childForm
{
    partial class childForm_personalInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_baseInfo = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label_dept = new System.Windows.Forms.Label();
            this.label_email = new System.Windows.Forms.Label();
            this.label_empNo = new System.Windows.Forms.Label();
            this.label_age = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.label_gender = new System.Windows.Forms.Label();
            this.label_role = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label_uname = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label_hello = new System.Windows.Forms.Label();
            this.panel_salary = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label_realSalary = new System.Windows.Forms.Label();
            this.label_yingkou = new System.Windows.Forms.Label();
            this.label_shuilv = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label_jiabanfei = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label_yingfa = new System.Windows.Forms.Label();
            this.label_butie = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label_jiangjin = new System.Windows.Forms.Label();
            this.label_baseSalary = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label_overTime = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label_realDay = new System.Windows.Forms.Label();
            this.label_shouldDay = new System.Windows.Forms.Label();
            this.label_kuang = new System.Windows.Forms.Label();
            this.label_earlyLeave = new System.Windows.Forms.Label();
            this.label_late = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.panel_resetPwd = new System.Windows.Forms.Panel();
            this.panel_changePwd02 = new System.Windows.Forms.Panel();
            this.button_cPwdCancel = new System.Windows.Forms.Button();
            this.btn_cPwdDone = new System.Windows.Forms.Button();
            this.textBox_newPwd02 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox_newPwd01 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox_oldPwd = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel_changePwd01 = new System.Windows.Forms.Panel();
            this.btn_showCPwd = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel_baseInfo.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel_salary.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel_resetPwd.SuspendLayout();
            this.panel_changePwd02.SuspendLayout();
            this.panel_changePwd01.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(137)))), ((int)(((byte)(152)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1060, 44);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.LightGray;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "位置：个人信息";
            // 
            // panel_baseInfo
            // 
            this.panel_baseInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(225)))), ((int)(((byte)(173)))));
            this.panel_baseInfo.Controls.Add(this.groupBox1);
            this.panel_baseInfo.Controls.Add(this.label_hello);
            this.panel_baseInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_baseInfo.Location = new System.Drawing.Point(0, 44);
            this.panel_baseInfo.Name = "panel_baseInfo";
            this.panel_baseInfo.Size = new System.Drawing.Size(1060, 215);
            this.panel_baseInfo.TabIndex = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.groupBox1.Controls.Add(this.label_dept);
            this.groupBox1.Controls.Add(this.label_email);
            this.groupBox1.Controls.Add(this.label_empNo);
            this.groupBox1.Controls.Add(this.label_age);
            this.groupBox1.Controls.Add(this.label_name);
            this.groupBox1.Controls.Add(this.label_gender);
            this.groupBox1.Controls.Add(this.label_role);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label_uname);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox1.Location = new System.Drawing.Point(8, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1045, 169);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "基本资料";
            // 
            // label_dept
            // 
            this.label_dept.AutoSize = true;
            this.label_dept.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_dept.Location = new System.Drawing.Point(786, 50);
            this.label_dept.Name = "label_dept";
            this.label_dept.Size = new System.Drawing.Size(57, 27);
            this.label_dept.TabIndex = 8;
            this.label_dept.Text = "×××";
            // 
            // label_email
            // 
            this.label_email.AutoSize = true;
            this.label_email.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_email.Location = new System.Drawing.Point(786, 97);
            this.label_email.Name = "label_email";
            this.label_email.Size = new System.Drawing.Size(161, 27);
            this.label_email.TabIndex = 8;
            this.label_email.Text = "×××@163.com";
            // 
            // label_empNo
            // 
            this.label_empNo.AutoSize = true;
            this.label_empNo.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_empNo.Location = new System.Drawing.Point(543, 48);
            this.label_empNo.Name = "label_empNo";
            this.label_empNo.Size = new System.Drawing.Size(60, 27);
            this.label_empNo.TabIndex = 8;
            this.label_empNo.Text = "0000";
            // 
            // label_age
            // 
            this.label_age.AutoSize = true;
            this.label_age.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_age.Location = new System.Drawing.Point(543, 96);
            this.label_age.Name = "label_age";
            this.label_age.Size = new System.Drawing.Size(57, 27);
            this.label_age.TabIndex = 8;
            this.label_age.Text = "×××";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_name.Location = new System.Drawing.Point(319, 47);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(57, 27);
            this.label_name.TabIndex = 8;
            this.label_name.Text = "×××";
            // 
            // label_gender
            // 
            this.label_gender.AutoSize = true;
            this.label_gender.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_gender.Location = new System.Drawing.Point(319, 98);
            this.label_gender.Name = "label_gender";
            this.label_gender.Size = new System.Drawing.Size(57, 27);
            this.label_gender.TabIndex = 8;
            this.label_gender.Text = "×××";
            // 
            // label_role
            // 
            this.label_role.AutoSize = true;
            this.label_role.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_role.Location = new System.Drawing.Point(114, 100);
            this.label_role.Name = "label_role";
            this.label_role.Size = new System.Drawing.Size(57, 27);
            this.label_role.TabIndex = 8;
            this.label_role.Text = "×××";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(473, 97);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 25);
            this.label12.TabIndex = 7;
            this.label12.Text = "年  龄：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(244, 48);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 25);
            this.label14.TabIndex = 7;
            this.label14.Text = "姓  名：";
            // 
            // label_uname
            // 
            this.label_uname.AutoSize = true;
            this.label_uname.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_uname.Location = new System.Drawing.Point(111, 48);
            this.label_uname.Name = "label_uname";
            this.label_uname.Size = new System.Drawing.Size(57, 27);
            this.label_uname.TabIndex = 8;
            this.label_uname.Text = "×××";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(244, 99);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 25);
            this.label10.TabIndex = 7;
            this.label10.Text = "性  别：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(447, 47);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 25);
            this.label8.TabIndex = 7;
            this.label8.Text = "员工编号：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(689, 50);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(107, 25);
            this.label16.TabIndex = 7;
            this.label16.Text = "所在部门：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 25);
            this.label6.TabIndex = 7;
            this.label6.Text = "职  务：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(689, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "电子邮箱：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "用户名：";
            // 
            // label_hello
            // 
            this.label_hello.AutoSize = true;
            this.label_hello.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_hello.ForeColor = System.Drawing.Color.White;
            this.label_hello.Location = new System.Drawing.Point(12, 6);
            this.label_hello.Name = "label_hello";
            this.label_hello.Size = new System.Drawing.Size(153, 25);
            this.label_hello.TabIndex = 0;
            this.label_hello.Text = "Hello，World！";
            // 
            // panel_salary
            // 
            this.panel_salary.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(206)))), ((int)(((byte)(246)))));
            this.panel_salary.Controls.Add(this.groupBox3);
            this.panel_salary.Controls.Add(this.groupBox2);
            this.panel_salary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_salary.Location = new System.Drawing.Point(0, 259);
            this.panel_salary.Name = "panel_salary";
            this.panel_salary.Size = new System.Drawing.Size(727, 451);
            this.panel_salary.TabIndex = 7;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.groupBox3.Controls.Add(this.label_realSalary);
            this.groupBox3.Controls.Add(this.label_yingkou);
            this.groupBox3.Controls.Add(this.label_shuilv);
            this.groupBox3.Controls.Add(this.label41);
            this.groupBox3.Controls.Add(this.label_jiabanfei);
            this.groupBox3.Controls.Add(this.label43);
            this.groupBox3.Controls.Add(this.label_yingfa);
            this.groupBox3.Controls.Add(this.label_butie);
            this.groupBox3.Controls.Add(this.label46);
            this.groupBox3.Controls.Add(this.label47);
            this.groupBox3.Controls.Add(this.label48);
            this.groupBox3.Controls.Add(this.label49);
            this.groupBox3.Controls.Add(this.label_jiangjin);
            this.groupBox3.Controls.Add(this.label_baseSalary);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox3.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox3.Location = new System.Drawing.Point(374, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(345, 438);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "薪资信息";
            // 
            // label_realSalary
            // 
            this.label_realSalary.AutoSize = true;
            this.label_realSalary.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_realSalary.Location = new System.Drawing.Point(169, 364);
            this.label_realSalary.Name = "label_realSalary";
            this.label_realSalary.Size = new System.Drawing.Size(79, 27);
            this.label_realSalary.TabIndex = 20;
            this.label_realSalary.Text = "0.00 元";
            // 
            // label_yingkou
            // 
            this.label_yingkou.AutoSize = true;
            this.label_yingkou.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_yingkou.Location = new System.Drawing.Point(169, 229);
            this.label_yingkou.Name = "label_yingkou";
            this.label_yingkou.Size = new System.Drawing.Size(79, 27);
            this.label_yingkou.TabIndex = 19;
            this.label_yingkou.Text = "0.00 元";
            // 
            // label_shuilv
            // 
            this.label_shuilv.AutoSize = true;
            this.label_shuilv.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_shuilv.Location = new System.Drawing.Point(169, 319);
            this.label_shuilv.Name = "label_shuilv";
            this.label_shuilv.Size = new System.Drawing.Size(65, 27);
            this.label_shuilv.TabIndex = 21;
            this.label_shuilv.Text = "0.0 %";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.Location = new System.Drawing.Point(65, 365);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(107, 25);
            this.label41.TabIndex = 18;
            this.label41.Text = "实发工资：";
            // 
            // label_jiabanfei
            // 
            this.label_jiabanfei.AutoSize = true;
            this.label_jiabanfei.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_jiabanfei.Location = new System.Drawing.Point(169, 184);
            this.label_jiabanfei.Name = "label_jiabanfei";
            this.label_jiabanfei.Size = new System.Drawing.Size(79, 27);
            this.label_jiabanfei.TabIndex = 22;
            this.label_jiabanfei.Text = "0.00 元";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.Location = new System.Drawing.Point(65, 230);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(107, 25);
            this.label43.TabIndex = 17;
            this.label43.Text = "应扣工资：";
            // 
            // label_yingfa
            // 
            this.label_yingfa.AutoSize = true;
            this.label_yingfa.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_yingfa.Location = new System.Drawing.Point(169, 274);
            this.label_yingfa.Name = "label_yingfa";
            this.label_yingfa.Size = new System.Drawing.Size(79, 27);
            this.label_yingfa.TabIndex = 23;
            this.label_yingfa.Text = "0.00 元";
            // 
            // label_butie
            // 
            this.label_butie.AutoSize = true;
            this.label_butie.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_butie.Location = new System.Drawing.Point(169, 139);
            this.label_butie.Name = "label_butie";
            this.label_butie.Size = new System.Drawing.Size(79, 27);
            this.label_butie.TabIndex = 24;
            this.label_butie.Text = "0.00 元";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label46.Location = new System.Drawing.Point(91, 320);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(81, 25);
            this.label46.TabIndex = 13;
            this.label46.Text = "税  率：";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label47.Location = new System.Drawing.Point(84, 185);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(88, 25);
            this.label47.TabIndex = 16;
            this.label47.Text = "加班费：";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label48.Location = new System.Drawing.Point(65, 275);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(107, 25);
            this.label48.TabIndex = 15;
            this.label48.Text = "应发工资：";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label49.Location = new System.Drawing.Point(91, 140);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(81, 25);
            this.label49.TabIndex = 14;
            this.label49.Text = "补  贴：";
            // 
            // label_jiangjin
            // 
            this.label_jiangjin.AutoSize = true;
            this.label_jiangjin.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_jiangjin.Location = new System.Drawing.Point(169, 94);
            this.label_jiangjin.Name = "label_jiangjin";
            this.label_jiangjin.Size = new System.Drawing.Size(79, 27);
            this.label_jiangjin.TabIndex = 11;
            this.label_jiangjin.Text = "0.00 元";
            // 
            // label_baseSalary
            // 
            this.label_baseSalary.AutoSize = true;
            this.label_baseSalary.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_baseSalary.Location = new System.Drawing.Point(169, 49);
            this.label_baseSalary.Name = "label_baseSalary";
            this.label_baseSalary.Size = new System.Drawing.Size(79, 27);
            this.label_baseSalary.TabIndex = 12;
            this.label_baseSalary.Text = "0.00 元";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.Location = new System.Drawing.Point(91, 95);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(81, 25);
            this.label36.TabIndex = 9;
            this.label36.Text = "奖  金：";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.Location = new System.Drawing.Point(91, 50);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(81, 25);
            this.label37.TabIndex = 10;
            this.label37.Text = "底  薪：";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.groupBox2.Controls.Add(this.label_overTime);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.label_realDay);
            this.groupBox2.Controls.Add(this.label_shouldDay);
            this.groupBox2.Controls.Add(this.label_kuang);
            this.groupBox2.Controls.Add(this.label_earlyLeave);
            this.groupBox2.Controls.Add(this.label_late);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox2.Location = new System.Drawing.Point(8, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(358, 438);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "考勤信息";
            // 
            // label_overTime
            // 
            this.label_overTime.AutoSize = true;
            this.label_overTime.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_overTime.Location = new System.Drawing.Point(193, 320);
            this.label_overTime.Name = "label_overTime";
            this.label_overTime.Size = new System.Drawing.Size(70, 27);
            this.label_overTime.TabIndex = 18;
            this.label_overTime.Text = "0 小时";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(65, 321);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(126, 25);
            this.label33.TabIndex = 17;
            this.label33.Text = "加班小时数：";
            // 
            // label_realDay
            // 
            this.label_realDay.AutoSize = true;
            this.label_realDay.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_realDay.Location = new System.Drawing.Point(193, 276);
            this.label_realDay.Name = "label_realDay";
            this.label_realDay.Size = new System.Drawing.Size(50, 27);
            this.label_realDay.TabIndex = 13;
            this.label_realDay.Text = "0 天";
            // 
            // label_shouldDay
            // 
            this.label_shouldDay.AutoSize = true;
            this.label_shouldDay.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_shouldDay.Location = new System.Drawing.Point(193, 225);
            this.label_shouldDay.Name = "label_shouldDay";
            this.label_shouldDay.Size = new System.Drawing.Size(50, 27);
            this.label_shouldDay.TabIndex = 12;
            this.label_shouldDay.Text = "0 天";
            // 
            // label_kuang
            // 
            this.label_kuang.AutoSize = true;
            this.label_kuang.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_kuang.Location = new System.Drawing.Point(193, 177);
            this.label_kuang.Name = "label_kuang";
            this.label_kuang.Size = new System.Drawing.Size(50, 27);
            this.label_kuang.TabIndex = 14;
            this.label_kuang.Text = "0 次";
            // 
            // label_earlyLeave
            // 
            this.label_earlyLeave.AutoSize = true;
            this.label_earlyLeave.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_earlyLeave.Location = new System.Drawing.Point(193, 127);
            this.label_earlyLeave.Name = "label_earlyLeave";
            this.label_earlyLeave.Size = new System.Drawing.Size(50, 27);
            this.label_earlyLeave.TabIndex = 16;
            this.label_earlyLeave.Text = "0 次";
            // 
            // label_late
            // 
            this.label_late.AutoSize = true;
            this.label_late.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_late.Location = new System.Drawing.Point(193, 81);
            this.label_late.Name = "label_late";
            this.label_late.Size = new System.Drawing.Size(50, 27);
            this.label_late.TabIndex = 15;
            this.label_late.Text = "0 次";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(46, 276);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(145, 25);
            this.label27.TabIndex = 8;
            this.label27.Text = "实际出勤天数：";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(84, 177);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(107, 25);
            this.label28.TabIndex = 7;
            this.label28.Text = "旷到次数：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(84, 128);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(107, 25);
            this.label29.TabIndex = 9;
            this.label29.Text = "早退次数：";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(84, 79);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(107, 25);
            this.label30.TabIndex = 11;
            this.label30.Text = "迟到次数：";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(65, 225);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(126, 25);
            this.label31.TabIndex = 10;
            this.label31.Text = "应出勤天数：";
            // 
            // panel_resetPwd
            // 
            this.panel_resetPwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(252)))), ((int)(((byte)(255)))));
            this.panel_resetPwd.Controls.Add(this.panel_changePwd02);
            this.panel_resetPwd.Controls.Add(this.panel_changePwd01);
            this.panel_resetPwd.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_resetPwd.Location = new System.Drawing.Point(727, 259);
            this.panel_resetPwd.Name = "panel_resetPwd";
            this.panel_resetPwd.Size = new System.Drawing.Size(333, 451);
            this.panel_resetPwd.TabIndex = 6;
            // 
            // panel_changePwd02
            // 
            this.panel_changePwd02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(236)))), ((int)(((byte)(240)))));
            this.panel_changePwd02.Controls.Add(this.button_cPwdCancel);
            this.panel_changePwd02.Controls.Add(this.btn_cPwdDone);
            this.panel_changePwd02.Controls.Add(this.textBox_newPwd02);
            this.panel_changePwd02.Controls.Add(this.label20);
            this.panel_changePwd02.Controls.Add(this.textBox_newPwd01);
            this.panel_changePwd02.Controls.Add(this.label19);
            this.panel_changePwd02.Controls.Add(this.textBox_oldPwd);
            this.panel_changePwd02.Controls.Add(this.label18);
            this.panel_changePwd02.Controls.Add(this.label21);
            this.panel_changePwd02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_changePwd02.Location = new System.Drawing.Point(0, 451);
            this.panel_changePwd02.Name = "panel_changePwd02";
            this.panel_changePwd02.Size = new System.Drawing.Size(333, 0);
            this.panel_changePwd02.TabIndex = 1;
            // 
            // button_cPwdCancel
            // 
            this.button_cPwdCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.button_cPwdCancel.FlatAppearance.BorderSize = 0;
            this.button_cPwdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_cPwdCancel.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button_cPwdCancel.ForeColor = System.Drawing.Color.White;
            this.button_cPwdCancel.Location = new System.Drawing.Point(209, 340);
            this.button_cPwdCancel.Name = "button_cPwdCancel";
            this.button_cPwdCancel.Size = new System.Drawing.Size(97, 40);
            this.button_cPwdCancel.TabIndex = 4;
            this.button_cPwdCancel.Text = "取  消";
            this.button_cPwdCancel.UseVisualStyleBackColor = false;
            this.button_cPwdCancel.Click += new System.EventHandler(this.button_cPwdCancel_Click);
            // 
            // btn_cPwdDone
            // 
            this.btn_cPwdDone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.btn_cPwdDone.FlatAppearance.BorderSize = 0;
            this.btn_cPwdDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cPwdDone.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_cPwdDone.ForeColor = System.Drawing.Color.White;
            this.btn_cPwdDone.Location = new System.Drawing.Point(72, 340);
            this.btn_cPwdDone.Name = "btn_cPwdDone";
            this.btn_cPwdDone.Size = new System.Drawing.Size(120, 40);
            this.btn_cPwdDone.TabIndex = 4;
            this.btn_cPwdDone.Text = "确认修改";
            this.btn_cPwdDone.UseVisualStyleBackColor = false;
            this.btn_cPwdDone.Click += new System.EventHandler(this.btn_cPwdDone_Click);
            // 
            // textBox_newPwd02
            // 
            this.textBox_newPwd02.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_newPwd02.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_newPwd02.Location = new System.Drawing.Point(136, 262);
            this.textBox_newPwd02.Name = "textBox_newPwd02";
            this.textBox_newPwd02.Size = new System.Drawing.Size(170, 26);
            this.textBox_newPwd02.TabIndex = 9;
            this.textBox_newPwd02.UseSystemPasswordChar = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(40, 265);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(106, 21);
            this.label20.TabIndex = 10;
            this.label20.Text = "确认新密码：";
            // 
            // textBox_newPwd01
            // 
            this.textBox_newPwd01.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_newPwd01.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_newPwd01.Location = new System.Drawing.Point(136, 206);
            this.textBox_newPwd01.Name = "textBox_newPwd01";
            this.textBox_newPwd01.Size = new System.Drawing.Size(170, 26);
            this.textBox_newPwd01.TabIndex = 9;
            this.textBox_newPwd01.UseSystemPasswordChar = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(40, 208);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(106, 21);
            this.label19.TabIndex = 10;
            this.label19.Text = "输入新密码：";
            // 
            // textBox_oldPwd
            // 
            this.textBox_oldPwd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_oldPwd.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_oldPwd.Location = new System.Drawing.Point(136, 150);
            this.textBox_oldPwd.Name = "textBox_oldPwd";
            this.textBox_oldPwd.Size = new System.Drawing.Size(170, 26);
            this.textBox_oldPwd.TabIndex = 9;
            this.textBox_oldPwd.UseSystemPasswordChar = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(24, 152);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(122, 21);
            this.label18.TabIndex = 10;
            this.label18.Text = "请输入旧密码：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(99, 69);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(133, 39);
            this.label21.TabIndex = 7;
            this.label21.Text = "修改密码";
            // 
            // panel_changePwd01
            // 
            this.panel_changePwd01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(252)))), ((int)(((byte)(255)))));
            this.panel_changePwd01.Controls.Add(this.btn_showCPwd);
            this.panel_changePwd01.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_changePwd01.Location = new System.Drawing.Point(0, 0);
            this.panel_changePwd01.Name = "panel_changePwd01";
            this.panel_changePwd01.Size = new System.Drawing.Size(333, 451);
            this.panel_changePwd01.TabIndex = 0;
            // 
            // btn_showCPwd
            // 
            this.btn_showCPwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.btn_showCPwd.FlatAppearance.BorderSize = 0;
            this.btn_showCPwd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_showCPwd.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_showCPwd.ForeColor = System.Drawing.Color.White;
            this.btn_showCPwd.Location = new System.Drawing.Point(106, 233);
            this.btn_showCPwd.Name = "btn_showCPwd";
            this.btn_showCPwd.Size = new System.Drawing.Size(141, 40);
            this.btn_showCPwd.TabIndex = 4;
            this.btn_showCPwd.Text = "点击修改密码";
            this.btn_showCPwd.UseVisualStyleBackColor = false;
            this.btn_showCPwd.Click += new System.EventHandler(this.btn_showCPwd_Click);
            // 
            // childForm_personalInfo
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1060, 710);
            this.Controls.Add(this.panel_salary);
            this.Controls.Add(this.panel_resetPwd);
            this.Controls.Add(this.panel_baseInfo);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "childForm_personalInfo";
            this.Text = "childForm_personalInfo";
            this.Load += new System.EventHandler(this.childForm_personalInfo_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel_baseInfo.ResumeLayout(false);
            this.panel_baseInfo.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel_salary.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel_resetPwd.ResumeLayout(false);
            this.panel_changePwd02.ResumeLayout(false);
            this.panel_changePwd02.PerformLayout();
            this.panel_changePwd01.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_baseInfo;
        private System.Windows.Forms.Label label_hello;
        private System.Windows.Forms.Panel panel_salary;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label_uname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label_email;
        private System.Windows.Forms.Label label_role;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_empNo;
        private System.Windows.Forms.Label label_age;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_gender;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label_dept;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel_resetPwd;
        private System.Windows.Forms.Panel panel_changePwd02;
        private System.Windows.Forms.Panel panel_changePwd01;
        private System.Windows.Forms.Button btn_showCPwd;
        private System.Windows.Forms.Button btn_cPwdDone;
        private System.Windows.Forms.TextBox textBox_newPwd02;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox_newPwd01;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox_oldPwd;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button_cPwdCancel;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label_realDay;
        private System.Windows.Forms.Label label_shouldDay;
        private System.Windows.Forms.Label label_kuang;
        private System.Windows.Forms.Label label_earlyLeave;
        private System.Windows.Forms.Label label_late;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label_overTime;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label_jiangjin;
        private System.Windows.Forms.Label label_baseSalary;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label_realSalary;
        private System.Windows.Forms.Label label_yingkou;
        private System.Windows.Forms.Label label_shuilv;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label_jiabanfei;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label_yingfa;
        private System.Windows.Forms.Label label_butie;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
    }
}