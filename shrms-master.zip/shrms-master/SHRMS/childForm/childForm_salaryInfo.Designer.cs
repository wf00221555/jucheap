﻿namespace SHRMS.childForm
{
    partial class childForm_salaryInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_top = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_center = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label_realSalary = new System.Windows.Forms.Label();
            this.label_yingkou = new System.Windows.Forms.Label();
            this.label_jiangjin = new System.Windows.Forms.Label();
            this.label_role = new System.Windows.Forms.Label();
            this.label_shuilv = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label_jiabanfei = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label_baseSalary = new System.Windows.Forms.Label();
            this.label_yingfa = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label_butie = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label_dept = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label_empNo = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox_str = new System.Windows.Forms.TextBox();
            this.label_query = new System.Windows.Forms.Label();
            this.btn_allInfo = new System.Windows.Forms.Button();
            this.btn_query = new System.Windows.Forms.Button();
            this.panel_bottom = new System.Windows.Forms.Panel();
            this.dataGridView_salary = new System.Windows.Forms.DataGridView();
            this.panel_top.SuspendLayout();
            this.panel_center.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel_bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_salary)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_top
            // 
            this.panel_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(137)))), ((int)(((byte)(152)))));
            this.panel_top.Controls.Add(this.label1);
            this.panel_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_top.Location = new System.Drawing.Point(0, 0);
            this.panel_top.Name = "panel_top";
            this.panel_top.Size = new System.Drawing.Size(1060, 44);
            this.panel_top.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.LightGray;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(376, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "位置：薪资管理 > 薪资信息";
            // 
            // panel_center
            // 
            this.panel_center.Controls.Add(this.groupBox2);
            this.panel_center.Controls.Add(this.groupBox1);
            this.panel_center.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_center.Location = new System.Drawing.Point(0, 44);
            this.panel_center.Name = "panel_center";
            this.panel_center.Size = new System.Drawing.Size(1060, 312);
            this.panel_center.TabIndex = 6;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label_realSalary);
            this.groupBox2.Controls.Add(this.label_yingkou);
            this.groupBox2.Controls.Add(this.label_jiangjin);
            this.groupBox2.Controls.Add(this.label_role);
            this.groupBox2.Controls.Add(this.label_shuilv);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label_jiabanfei);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label_baseSalary);
            this.groupBox2.Controls.Add(this.label_yingfa);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label_butie);
            this.groupBox2.Controls.Add(this.label_name);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label_dept);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label_empNo);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox2.Location = new System.Drawing.Point(12, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1036, 191);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "薪资信息";
            // 
            // label_realSalary
            // 
            this.label_realSalary.AutoSize = true;
            this.label_realSalary.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_realSalary.Location = new System.Drawing.Point(876, 139);
            this.label_realSalary.Name = "label_realSalary";
            this.label_realSalary.Size = new System.Drawing.Size(117, 39);
            this.label_realSalary.TabIndex = 8;
            this.label_realSalary.Text = "0.00 元";
            // 
            // label_yingkou
            // 
            this.label_yingkou.AutoSize = true;
            this.label_yingkou.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_yingkou.Location = new System.Drawing.Point(632, 138);
            this.label_yingkou.Name = "label_yingkou";
            this.label_yingkou.Size = new System.Drawing.Size(117, 39);
            this.label_yingkou.TabIndex = 8;
            this.label_yingkou.Text = "0.00 元";
            // 
            // label_jiangjin
            // 
            this.label_jiangjin.AutoSize = true;
            this.label_jiangjin.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_jiangjin.Location = new System.Drawing.Point(381, 137);
            this.label_jiangjin.Name = "label_jiangjin";
            this.label_jiangjin.Size = new System.Drawing.Size(117, 39);
            this.label_jiangjin.TabIndex = 8;
            this.label_jiangjin.Text = "0.00 元";
            // 
            // label_role
            // 
            this.label_role.AutoSize = true;
            this.label_role.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_role.Location = new System.Drawing.Point(156, 138);
            this.label_role.Name = "label_role";
            this.label_role.Size = new System.Drawing.Size(83, 39);
            this.label_role.TabIndex = 8;
            this.label_role.Text = "×××";
            // 
            // label_shuilv
            // 
            this.label_shuilv.AutoSize = true;
            this.label_shuilv.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_shuilv.Location = new System.Drawing.Point(876, 92);
            this.label_shuilv.Name = "label_shuilv";
            this.label_shuilv.Size = new System.Drawing.Size(96, 39);
            this.label_shuilv.TabIndex = 8;
            this.label_shuilv.Text = "0.0 %";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(787, 140);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(162, 38);
            this.label23.TabIndex = 7;
            this.label23.Text = "实发工资：";
            // 
            // label_jiabanfei
            // 
            this.label_jiabanfei.AutoSize = true;
            this.label_jiabanfei.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_jiabanfei.Location = new System.Drawing.Point(632, 91);
            this.label_jiabanfei.Name = "label_jiabanfei";
            this.label_jiabanfei.Size = new System.Drawing.Size(117, 39);
            this.label_jiabanfei.TabIndex = 8;
            this.label_jiabanfei.Text = "0.00 元";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(543, 139);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(162, 38);
            this.label17.TabIndex = 7;
            this.label17.Text = "应扣工资：";
            // 
            // label_baseSalary
            // 
            this.label_baseSalary.AutoSize = true;
            this.label_baseSalary.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_baseSalary.Location = new System.Drawing.Point(381, 90);
            this.label_baseSalary.Name = "label_baseSalary";
            this.label_baseSalary.Size = new System.Drawing.Size(117, 39);
            this.label_baseSalary.TabIndex = 8;
            this.label_baseSalary.Text = "0.00 元";
            // 
            // label_yingfa
            // 
            this.label_yingfa.AutoSize = true;
            this.label_yingfa.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_yingfa.Location = new System.Drawing.Point(876, 46);
            this.label_yingfa.Name = "label_yingfa";
            this.label_yingfa.Size = new System.Drawing.Size(117, 39);
            this.label_yingfa.TabIndex = 8;
            this.label_yingfa.Text = "0.00 元";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(318, 138);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 38);
            this.label11.TabIndex = 7;
            this.label11.Text = "奖  金：";
            // 
            // label_butie
            // 
            this.label_butie.AutoSize = true;
            this.label_butie.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_butie.Location = new System.Drawing.Point(632, 45);
            this.label_butie.Name = "label_butie";
            this.label_butie.Size = new System.Drawing.Size(117, 39);
            this.label_butie.TabIndex = 8;
            this.label_butie.Text = "0.00 元";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_name.Location = new System.Drawing.Point(381, 44);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(83, 39);
            this.label_name.TabIndex = 8;
            this.label_name.Text = "×××";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(813, 93);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(122, 38);
            this.label21.TabIndex = 7;
            this.label21.Text = "税  率：";
            // 
            // label_dept
            // 
            this.label_dept.AutoSize = true;
            this.label_dept.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_dept.Location = new System.Drawing.Point(156, 92);
            this.label_dept.Name = "label_dept";
            this.label_dept.Size = new System.Drawing.Size(83, 39);
            this.label_dept.TabIndex = 8;
            this.label_dept.Text = "×××";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(561, 92);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(133, 38);
            this.label15.TabIndex = 7;
            this.label15.Text = "加班费：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(67, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(162, 38);
            this.label4.TabIndex = 7;
            this.label4.Text = "员工职务：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(787, 47);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(162, 38);
            this.label20.TabIndex = 7;
            this.label20.Text = "应发工资：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(318, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 38);
            this.label8.TabIndex = 7;
            this.label8.Text = "底  薪：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.Location = new System.Drawing.Point(567, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(122, 38);
            this.label14.TabIndex = 7;
            this.label14.Text = "补  贴：";
            // 
            // label_empNo
            // 
            this.label_empNo.AutoSize = true;
            this.label_empNo.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_empNo.Location = new System.Drawing.Point(156, 45);
            this.label_empNo.Name = "label_empNo";
            this.label_empNo.Size = new System.Drawing.Size(89, 39);
            this.label_empNo.TabIndex = 8;
            this.label_empNo.Text = "0000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(67, 93);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(162, 38);
            this.label7.TabIndex = 7;
            this.label7.Text = "所在部门：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(317, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 38);
            this.label2.TabIndex = 7;
            this.label2.Text = "姓  名：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(67, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(162, 38);
            this.label5.TabIndex = 7;
            this.label5.Text = "员工编号：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox_str);
            this.groupBox1.Controls.Add(this.label_query);
            this.groupBox1.Controls.Add(this.btn_allInfo);
            this.groupBox1.Controls.Add(this.btn_query);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox1.Location = new System.Drawing.Point(12, 203);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1036, 96);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "快速查找";
            // 
            // textBox_str
            // 
            this.textBox_str.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_str.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_str.Location = new System.Drawing.Point(652, 40);
            this.textBox_str.Name = "textBox_str";
            this.textBox_str.Size = new System.Drawing.Size(141, 38);
            this.textBox_str.TabIndex = 49;
            // 
            // label_query
            // 
            this.label_query.AutoSize = true;
            this.label_query.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_query.Location = new System.Drawing.Point(498, 40);
            this.label_query.Name = "label_query";
            this.label_query.Size = new System.Drawing.Size(227, 38);
            this.label_query.TabIndex = 51;
            this.label_query.Text = "按员工编号查询:";
            // 
            // btn_allInfo
            // 
            this.btn_allInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.btn_allInfo.FlatAppearance.BorderSize = 0;
            this.btn_allInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_allInfo.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_allInfo.ForeColor = System.Drawing.Color.White;
            this.btn_allInfo.Location = new System.Drawing.Point(237, 32);
            this.btn_allInfo.Name = "btn_allInfo";
            this.btn_allInfo.Size = new System.Drawing.Size(227, 40);
            this.btn_allInfo.TabIndex = 31;
            this.btn_allInfo.Text = "查看所有薪资信息";
            this.btn_allInfo.UseVisualStyleBackColor = false;
            this.btn_allInfo.Click += new System.EventHandler(this.btn_allInfo_Click);
            // 
            // btn_query
            // 
            this.btn_query.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.btn_query.FlatAppearance.BorderSize = 0;
            this.btn_query.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_query.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_query.ForeColor = System.Drawing.Color.White;
            this.btn_query.Location = new System.Drawing.Point(852, 32);
            this.btn_query.Name = "btn_query";
            this.btn_query.Size = new System.Drawing.Size(141, 40);
            this.btn_query.TabIndex = 31;
            this.btn_query.Text = "点击查询";
            this.btn_query.UseVisualStyleBackColor = false;
            this.btn_query.Click += new System.EventHandler(this.btn_query_Click);
            // 
            // panel_bottom
            // 
            this.panel_bottom.Controls.Add(this.dataGridView_salary);
            this.panel_bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_bottom.Location = new System.Drawing.Point(0, 356);
            this.panel_bottom.Name = "panel_bottom";
            this.panel_bottom.Size = new System.Drawing.Size(1060, 354);
            this.panel_bottom.TabIndex = 7;
            // 
            // dataGridView_salary
            // 
            this.dataGridView_salary.AllowUserToAddRows = false;
            this.dataGridView_salary.AllowUserToDeleteRows = false;
            this.dataGridView_salary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_salary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_salary.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_salary.Name = "dataGridView_salary";
            this.dataGridView_salary.ReadOnly = true;
            this.dataGridView_salary.RowTemplate.Height = 23;
            this.dataGridView_salary.Size = new System.Drawing.Size(1060, 354);
            this.dataGridView_salary.TabIndex = 0;
            this.dataGridView_salary.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_salary_CellClick);
            // 
            // childForm_salaryInfo
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1060, 710);
            this.Controls.Add(this.panel_bottom);
            this.Controls.Add(this.panel_center);
            this.Controls.Add(this.panel_top);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "childForm_salaryInfo";
            this.Text = "childForm_salaryInfo";
            this.panel_top.ResumeLayout(false);
            this.panel_top.PerformLayout();
            this.panel_center.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel_bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_salary)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_top;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_center;
        private System.Windows.Forms.Panel panel_bottom;
        private System.Windows.Forms.DataGridView dataGridView_salary;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox_str;
        private System.Windows.Forms.Label label_query;
        private System.Windows.Forms.Button btn_query;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label_empNo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label_realSalary;
        private System.Windows.Forms.Label label_yingkou;
        private System.Windows.Forms.Label label_jiangjin;
        private System.Windows.Forms.Label label_role;
        private System.Windows.Forms.Label label_shuilv;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label_jiabanfei;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label_baseSalary;
        private System.Windows.Forms.Label label_yingfa;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label_butie;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label_dept;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_allInfo;
    }
}