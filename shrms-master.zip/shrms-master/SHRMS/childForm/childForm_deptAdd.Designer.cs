﻿namespace SHRMS.childForm
{
    partial class childForm_deptAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_deptphone = new System.Windows.Forms.TextBox();
            this.btn_deptAdd = new System.Windows.Forms.Button();
            this.textBox_deptAddress = new System.Windows.Forms.TextBox();
            this.textBox_deptNo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_deptName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel_left = new System.Windows.Forms.Panel();
            this.panel_right = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel_left.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(137)))), ((int)(((byte)(152)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1060, 44);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.LightGray;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "位置：部门管理 > 添加部门";
            // 
            // textBox_deptphone
            // 
            this.textBox_deptphone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_deptphone.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_deptphone.Location = new System.Drawing.Point(220, 345);
            this.textBox_deptphone.Name = "textBox_deptphone";
            this.textBox_deptphone.Size = new System.Drawing.Size(242, 26);
            this.textBox_deptphone.TabIndex = 10;
            // 
            // btn_deptAdd
            // 
            this.btn_deptAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(223)))), ((int)(((byte)(163)))));
            this.btn_deptAdd.FlatAppearance.BorderSize = 0;
            this.btn_deptAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_deptAdd.Font = new System.Drawing.Font("微软雅黑", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_deptAdd.ForeColor = System.Drawing.Color.White;
            this.btn_deptAdd.Location = new System.Drawing.Point(220, 431);
            this.btn_deptAdd.Name = "btn_deptAdd";
            this.btn_deptAdd.Size = new System.Drawing.Size(242, 54);
            this.btn_deptAdd.TabIndex = 7;
            this.btn_deptAdd.Text = "点击添加部门";
            this.btn_deptAdd.UseVisualStyleBackColor = false;
            this.btn_deptAdd.Click += new System.EventHandler(this.btn_deptAdd_Click);
            // 
            // textBox_deptAddress
            // 
            this.textBox_deptAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_deptAddress.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_deptAddress.Location = new System.Drawing.Point(220, 277);
            this.textBox_deptAddress.Name = "textBox_deptAddress";
            this.textBox_deptAddress.Size = new System.Drawing.Size(242, 26);
            this.textBox_deptAddress.TabIndex = 11;
            // 
            // textBox_deptNo
            // 
            this.textBox_deptNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_deptNo.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_deptNo.Location = new System.Drawing.Point(220, 141);
            this.textBox_deptNo.Name = "textBox_deptNo";
            this.textBox_deptNo.Size = new System.Drawing.Size(242, 26);
            this.textBox_deptNo.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Location = new System.Drawing.Point(43, 346);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(164, 25);
            this.label7.TabIndex = 17;
            this.label7.Text = "该部门电话号码：";
            // 
            // textBox_deptName
            // 
            this.textBox_deptName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_deptName.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_deptName.Location = new System.Drawing.Point(220, 209);
            this.textBox_deptName.Name = "textBox_deptName";
            this.textBox_deptName.Size = new System.Drawing.Size(242, 26);
            this.textBox_deptName.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(43, 278);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "该部门所在地址：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(100, 142);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 25);
            this.label5.TabIndex = 12;
            this.label5.Text = "部门编号：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(100, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 25);
            this.label4.TabIndex = 14;
            this.label4.Text = "部门名称：";
            // 
            // panel_left
            // 
            this.panel_left.Controls.Add(this.textBox_deptphone);
            this.panel_left.Controls.Add(this.label4);
            this.panel_left.Controls.Add(this.label5);
            this.panel_left.Controls.Add(this.btn_deptAdd);
            this.panel_left.Controls.Add(this.label6);
            this.panel_left.Controls.Add(this.textBox_deptAddress);
            this.panel_left.Controls.Add(this.textBox_deptName);
            this.panel_left.Controls.Add(this.textBox_deptNo);
            this.panel_left.Controls.Add(this.label7);
            this.panel_left.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_left.Location = new System.Drawing.Point(0, 44);
            this.panel_left.Name = "panel_left";
            this.panel_left.Size = new System.Drawing.Size(517, 666);
            this.panel_left.TabIndex = 18;
            // 
            // panel_right
            // 
            this.panel_right.BackColor = System.Drawing.Color.Aqua;
            this.panel_right.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_right.Location = new System.Drawing.Point(517, 44);
            this.panel_right.Name = "panel_right";
            this.panel_right.Size = new System.Drawing.Size(543, 666);
            this.panel_right.TabIndex = 19;
            // 
            // childForm_deptAdd
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.ClientSize = new System.Drawing.Size(1060, 710);
            this.Controls.Add(this.panel_right);
            this.Controls.Add(this.panel_left);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "childForm_deptAdd";
            this.Text = "childForm_deptAdd";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel_left.ResumeLayout(false);
            this.panel_left.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_deptphone;
        private System.Windows.Forms.Button btn_deptAdd;
        private System.Windows.Forms.TextBox textBox_deptAddress;
        private System.Windows.Forms.TextBox textBox_deptNo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_deptName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel_left;
        private System.Windows.Forms.Panel panel_right;
    }
}