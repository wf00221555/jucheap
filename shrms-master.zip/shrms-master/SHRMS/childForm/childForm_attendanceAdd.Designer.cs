﻿namespace SHRMS.childForm
{
    partial class childForm_attendanceAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_top = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_left = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.numericUpDown_realDay = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_shouldDay = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_absenteeism = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_earlyLeave = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_late = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_overTime = new System.Windows.Forms.NumericUpDown();
            this.btn_modifyAtt = new System.Windows.Forms.Button();
            this.label_dept = new System.Windows.Forms.Label();
            this.label_role = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.label_empNo = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox_str = new System.Windows.Forms.TextBox();
            this.btn_AllInfo = new System.Windows.Forms.Button();
            this.btn_query = new System.Windows.Forms.Button();
            this.label_sType = new System.Windows.Forms.Label();
            this.panel_right = new System.Windows.Forms.Panel();
            this.dataGridView_att = new System.Windows.Forms.DataGridView();
            this.panel_top.SuspendLayout();
            this.panel_left.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_realDay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_shouldDay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_absenteeism)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_earlyLeave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_late)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_overTime)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel_right.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_att)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_top
            // 
            this.panel_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(137)))), ((int)(((byte)(152)))));
            this.panel_top.Controls.Add(this.label1);
            this.panel_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_top.Location = new System.Drawing.Point(0, 0);
            this.panel_top.Name = "panel_top";
            this.panel_top.Size = new System.Drawing.Size(1060, 44);
            this.panel_top.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.LightGray;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "位置：考勤管理 > 录入考勤";
            // 
            // panel_left
            // 
            this.panel_left.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(37)))), ((int)(((byte)(70)))));
            this.panel_left.Controls.Add(this.groupBox2);
            this.panel_left.Controls.Add(this.groupBox1);
            this.panel_left.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_left.Location = new System.Drawing.Point(0, 44);
            this.panel_left.Name = "panel_left";
            this.panel_left.Size = new System.Drawing.Size(505, 666);
            this.panel_left.TabIndex = 6;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.groupBox2.Controls.Add(this.numericUpDown_realDay);
            this.groupBox2.Controls.Add(this.numericUpDown_shouldDay);
            this.groupBox2.Controls.Add(this.numericUpDown_absenteeism);
            this.groupBox2.Controls.Add(this.numericUpDown_earlyLeave);
            this.groupBox2.Controls.Add(this.numericUpDown_late);
            this.groupBox2.Controls.Add(this.numericUpDown_overTime);
            this.groupBox2.Controls.Add(this.btn_modifyAtt);
            this.groupBox2.Controls.Add(this.label_dept);
            this.groupBox2.Controls.Add(this.label_role);
            this.groupBox2.Controls.Add(this.label_name);
            this.groupBox2.Controls.Add(this.label_empNo);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox2.Location = new System.Drawing.Point(12, 206);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(480, 448);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "员工考勤信息";
            // 
            // numericUpDown_realDay
            // 
            this.numericUpDown_realDay.Location = new System.Drawing.Point(364, 258);
            this.numericUpDown_realDay.Name = "numericUpDown_realDay";
            this.numericUpDown_realDay.Size = new System.Drawing.Size(59, 29);
            this.numericUpDown_realDay.TabIndex = 7;
            // 
            // numericUpDown_shouldDay
            // 
            this.numericUpDown_shouldDay.Location = new System.Drawing.Point(364, 206);
            this.numericUpDown_shouldDay.Name = "numericUpDown_shouldDay";
            this.numericUpDown_shouldDay.Size = new System.Drawing.Size(59, 29);
            this.numericUpDown_shouldDay.TabIndex = 7;
            // 
            // numericUpDown_absenteeism
            // 
            this.numericUpDown_absenteeism.Location = new System.Drawing.Point(364, 158);
            this.numericUpDown_absenteeism.Name = "numericUpDown_absenteeism";
            this.numericUpDown_absenteeism.Size = new System.Drawing.Size(59, 29);
            this.numericUpDown_absenteeism.TabIndex = 7;
            // 
            // numericUpDown_earlyLeave
            // 
            this.numericUpDown_earlyLeave.Location = new System.Drawing.Point(364, 110);
            this.numericUpDown_earlyLeave.Name = "numericUpDown_earlyLeave";
            this.numericUpDown_earlyLeave.Size = new System.Drawing.Size(59, 29);
            this.numericUpDown_earlyLeave.TabIndex = 7;
            // 
            // numericUpDown_late
            // 
            this.numericUpDown_late.Location = new System.Drawing.Point(364, 61);
            this.numericUpDown_late.Name = "numericUpDown_late";
            this.numericUpDown_late.Size = new System.Drawing.Size(59, 29);
            this.numericUpDown_late.TabIndex = 7;
            // 
            // numericUpDown_overTime
            // 
            this.numericUpDown_overTime.Location = new System.Drawing.Point(154, 257);
            this.numericUpDown_overTime.Name = "numericUpDown_overTime";
            this.numericUpDown_overTime.Size = new System.Drawing.Size(59, 29);
            this.numericUpDown_overTime.TabIndex = 7;
            // 
            // btn_modifyAtt
            // 
            this.btn_modifyAtt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(223)))), ((int)(((byte)(163)))));
            this.btn_modifyAtt.FlatAppearance.BorderSize = 0;
            this.btn_modifyAtt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_modifyAtt.ForeColor = System.Drawing.Color.White;
            this.btn_modifyAtt.Location = new System.Drawing.Point(290, 369);
            this.btn_modifyAtt.Name = "btn_modifyAtt";
            this.btn_modifyAtt.Size = new System.Drawing.Size(133, 40);
            this.btn_modifyAtt.TabIndex = 3;
            this.btn_modifyAtt.Text = "点击录入考勤";
            this.btn_modifyAtt.UseVisualStyleBackColor = false;
            this.btn_modifyAtt.Click += new System.EventHandler(this.btn_modifyAtt_Click);
            // 
            // label_dept
            // 
            this.label_dept.AutoSize = true;
            this.label_dept.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_dept.Location = new System.Drawing.Point(149, 209);
            this.label_dept.Name = "label_dept";
            this.label_dept.Size = new System.Drawing.Size(46, 21);
            this.label_dept.TabIndex = 6;
            this.label_dept.Text = "×××";
            // 
            // label_role
            // 
            this.label_role.AutoSize = true;
            this.label_role.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_role.Location = new System.Drawing.Point(149, 159);
            this.label_role.Name = "label_role";
            this.label_role.Size = new System.Drawing.Size(57, 27);
            this.label_role.TabIndex = 6;
            this.label_role.Text = "×××";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_name.Location = new System.Drawing.Point(149, 110);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(57, 27);
            this.label_name.TabIndex = 6;
            this.label_name.Text = "×××";
            // 
            // label_empNo
            // 
            this.label_empNo.AutoSize = true;
            this.label_empNo.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_empNo.Location = new System.Drawing.Point(149, 61);
            this.label_empNo.Name = "label_empNo";
            this.label_empNo.Size = new System.Drawing.Size(60, 27);
            this.label_empNo.TabIndex = 6;
            this.label_empNo.Text = "0000";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(60, 209);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 21);
            this.label14.TabIndex = 6;
            this.label14.Text = "所在部门：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(44, 260);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 21);
            this.label8.TabIndex = 6;
            this.label8.Text = "加班小时数：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(248, 260);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 21);
            this.label7.TabIndex = 6;
            this.label7.Text = "实际出勤天数：";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(280, 161);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 21);
            this.label13.TabIndex = 6;
            this.label13.Text = "旷到次数：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(280, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 21);
            this.label12.TabIndex = 6;
            this.label12.Text = "早退次数：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(280, 63);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 21);
            this.label11.TabIndex = 6;
            this.label11.Text = "迟到次数：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(264, 209);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 21);
            this.label6.TabIndex = 6;
            this.label6.Text = "应出勤天数：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(60, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 21);
            this.label5.TabIndex = 6;
            this.label5.Text = "员工编号：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(60, 161);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 21);
            this.label9.TabIndex = 6;
            this.label9.Text = "员工职务：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 21);
            this.label4.TabIndex = 6;
            this.label4.Text = "员工姓名：";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.groupBox1.Controls.Add(this.textBox_str);
            this.groupBox1.Controls.Add(this.btn_AllInfo);
            this.groupBox1.Controls.Add(this.btn_query);
            this.groupBox1.Controls.Add(this.label_sType);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox1.Location = new System.Drawing.Point(12, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(480, 178);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "快速查询";
            // 
            // textBox_str
            // 
            this.textBox_str.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_str.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_str.Location = new System.Drawing.Point(327, 54);
            this.textBox_str.Name = "textBox_str";
            this.textBox_str.Size = new System.Drawing.Size(141, 26);
            this.textBox_str.TabIndex = 5;
            // 
            // btn_AllInfo
            // 
            this.btn_AllInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.btn_AllInfo.FlatAppearance.BorderSize = 0;
            this.btn_AllInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AllInfo.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_AllInfo.ForeColor = System.Drawing.Color.White;
            this.btn_AllInfo.Location = new System.Drawing.Point(13, 113);
            this.btn_AllInfo.Name = "btn_AllInfo";
            this.btn_AllInfo.Size = new System.Drawing.Size(185, 40);
            this.btn_AllInfo.TabIndex = 3;
            this.btn_AllInfo.Text = "查看所有员工信息";
            this.btn_AllInfo.UseVisualStyleBackColor = false;
            this.btn_AllInfo.Click += new System.EventHandler(this.btn_AllInfo_Click);
            // 
            // btn_query
            // 
            this.btn_query.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(149)))), ((int)(((byte)(255)))));
            this.btn_query.FlatAppearance.BorderSize = 0;
            this.btn_query.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_query.ForeColor = System.Drawing.Color.White;
            this.btn_query.Location = new System.Drawing.Point(328, 113);
            this.btn_query.Name = "btn_query";
            this.btn_query.Size = new System.Drawing.Size(141, 40);
            this.btn_query.TabIndex = 3;
            this.btn_query.Text = "点击查询";
            this.btn_query.UseVisualStyleBackColor = false;
            this.btn_query.Click += new System.EventHandler(this.btn_query_Click);
            // 
            // label_sType
            // 
            this.label_sType.AutoSize = true;
            this.label_sType.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_sType.Location = new System.Drawing.Point(176, 54);
            this.label_sType.Name = "label_sType";
            this.label_sType.Size = new System.Drawing.Size(150, 25);
            this.label_sType.TabIndex = 6;
            this.label_sType.Text = "按员工编号查询:";
            // 
            // panel_right
            // 
            this.panel_right.Controls.Add(this.dataGridView_att);
            this.panel_right.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_right.Location = new System.Drawing.Point(505, 44);
            this.panel_right.Name = "panel_right";
            this.panel_right.Size = new System.Drawing.Size(555, 666);
            this.panel_right.TabIndex = 7;
            // 
            // dataGridView_att
            // 
            this.dataGridView_att.AllowUserToAddRows = false;
            this.dataGridView_att.AllowUserToDeleteRows = false;
            this.dataGridView_att.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_att.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_att.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_att.Name = "dataGridView_att";
            this.dataGridView_att.ReadOnly = true;
            this.dataGridView_att.RowTemplate.Height = 23;
            this.dataGridView_att.Size = new System.Drawing.Size(555, 666);
            this.dataGridView_att.TabIndex = 0;
            this.dataGridView_att.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_att_CellClick);
            // 
            // childForm_attendanceAdd
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1060, 710);
            this.Controls.Add(this.panel_right);
            this.Controls.Add(this.panel_left);
            this.Controls.Add(this.panel_top);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "childForm_attendanceAdd";
            this.Text = "childForm_attendanceAdd";
            this.panel_top.ResumeLayout(false);
            this.panel_top.PerformLayout();
            this.panel_left.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_realDay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_shouldDay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_absenteeism)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_earlyLeave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_late)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_overTime)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel_right.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_att)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_top;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_left;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown numericUpDown_realDay;
        private System.Windows.Forms.NumericUpDown numericUpDown_shouldDay;
        private System.Windows.Forms.NumericUpDown numericUpDown_absenteeism;
        private System.Windows.Forms.NumericUpDown numericUpDown_earlyLeave;
        private System.Windows.Forms.NumericUpDown numericUpDown_late;
        private System.Windows.Forms.NumericUpDown numericUpDown_overTime;
        private System.Windows.Forms.Button btn_modifyAtt;
        private System.Windows.Forms.Label label_dept;
        private System.Windows.Forms.Label label_role;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_empNo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox_str;
        private System.Windows.Forms.Button btn_AllInfo;
        private System.Windows.Forms.Button btn_query;
        private System.Windows.Forms.Label label_sType;
        private System.Windows.Forms.Panel panel_right;
        private System.Windows.Forms.DataGridView dataGridView_att;
    }
}