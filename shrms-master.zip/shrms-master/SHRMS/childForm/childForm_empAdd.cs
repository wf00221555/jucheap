﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SHRMS.childForm
{
    public partial class childForm_empAdd : Form
    {
        public childForm_empAdd()
        {
            InitializeComponent();
        }
    }
}
