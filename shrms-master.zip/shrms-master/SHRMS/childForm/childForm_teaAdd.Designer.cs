﻿namespace SHRMS.childForm
{
    partial class childForm_teaAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_top = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox_gender = new System.Windows.Forms.GroupBox();
            this.radioButton_woman = new System.Windows.Forms.RadioButton();
            this.radioButton_man = new System.Windows.Forms.RadioButton();
            this.comboBox_dept = new System.Windows.Forms.ComboBox();
            this.numericUpDown_No = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_bankCardNo = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_ID = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_age = new System.Windows.Forms.NumericUpDown();
            this.btn_teaAdd = new System.Windows.Forms.Button();
            this.textBox_stuS = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_Name = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox_edu = new System.Windows.Forms.ComboBox();
            this.monthCalendar_birthday = new System.Windows.Forms.MonthCalendar();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_teaching = new System.Windows.Forms.TextBox();
            this.panel_center = new System.Windows.Forms.Panel();
            this.panel_bottom = new System.Windows.Forms.Panel();
            this.textBox_uName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox_uPwd = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox_email = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label_birthday = new System.Windows.Forms.Label();
            this.panel_top.SuspendLayout();
            this.groupBox_gender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_No)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_bankCardNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_age)).BeginInit();
            this.panel_center.SuspendLayout();
            this.panel_bottom.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_top
            // 
            this.panel_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(137)))), ((int)(((byte)(152)))));
            this.panel_top.Controls.Add(this.label1);
            this.panel_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_top.Location = new System.Drawing.Point(0, 0);
            this.panel_top.Name = "panel_top";
            this.panel_top.Size = new System.Drawing.Size(1060, 44);
            this.panel_top.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.LightGray;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "位置：教师管理 > 添加教师";
            // 
            // groupBox_gender
            // 
            this.groupBox_gender.Controls.Add(this.radioButton_woman);
            this.groupBox_gender.Controls.Add(this.radioButton_man);
            this.groupBox_gender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox_gender.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox_gender.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox_gender.Location = new System.Drawing.Point(276, 145);
            this.groupBox_gender.Name = "groupBox_gender";
            this.groupBox_gender.Size = new System.Drawing.Size(143, 52);
            this.groupBox_gender.TabIndex = 46;
            this.groupBox_gender.TabStop = false;
            // 
            // radioButton_woman
            // 
            this.radioButton_woman.AutoSize = true;
            this.radioButton_woman.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.radioButton_woman.Location = new System.Drawing.Point(86, 19);
            this.radioButton_woman.Name = "radioButton_woman";
            this.radioButton_woman.Size = new System.Drawing.Size(44, 25);
            this.radioButton_woman.TabIndex = 0;
            this.radioButton_woman.TabStop = true;
            this.radioButton_woman.Text = "女";
            this.radioButton_woman.UseVisualStyleBackColor = true;
            // 
            // radioButton_man
            // 
            this.radioButton_man.AutoSize = true;
            this.radioButton_man.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.radioButton_man.Location = new System.Drawing.Point(22, 19);
            this.radioButton_man.Name = "radioButton_man";
            this.radioButton_man.Size = new System.Drawing.Size(44, 25);
            this.radioButton_man.TabIndex = 0;
            this.radioButton_man.TabStop = true;
            this.radioButton_man.Text = "男";
            this.radioButton_man.UseVisualStyleBackColor = true;
            // 
            // comboBox_dept
            // 
            this.comboBox_dept.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_dept.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.comboBox_dept.FormattingEnabled = true;
            this.comboBox_dept.Location = new System.Drawing.Point(278, 401);
            this.comboBox_dept.Name = "comboBox_dept";
            this.comboBox_dept.Size = new System.Drawing.Size(143, 29);
            this.comboBox_dept.TabIndex = 45;
            this.comboBox_dept.SelectedIndexChanged += new System.EventHandler(this.comboBox_dept_SelectedIndexChanged);
            // 
            // numericUpDown_No
            // 
            this.numericUpDown_No.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown_No.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_No.Location = new System.Drawing.Point(276, 30);
            this.numericUpDown_No.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.numericUpDown_No.Name = "numericUpDown_No";
            this.numericUpDown_No.Size = new System.Drawing.Size(143, 29);
            this.numericUpDown_No.TabIndex = 42;
            // 
            // numericUpDown_bankCardNo
            // 
            this.numericUpDown_bankCardNo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown_bankCardNo.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_bankCardNo.Location = new System.Drawing.Point(685, 144);
            this.numericUpDown_bankCardNo.Maximum = new decimal(new int[] {
            -1486618625,
            232830643,
            0,
            0});
            this.numericUpDown_bankCardNo.Name = "numericUpDown_bankCardNo";
            this.numericUpDown_bankCardNo.Size = new System.Drawing.Size(220, 25);
            this.numericUpDown_bankCardNo.TabIndex = 41;
            // 
            // numericUpDown_ID
            // 
            this.numericUpDown_ID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown_ID.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_ID.Location = new System.Drawing.Point(685, 87);
            this.numericUpDown_ID.Maximum = new decimal(new int[] {
            -1486618625,
            232830643,
            0,
            0});
            this.numericUpDown_ID.Name = "numericUpDown_ID";
            this.numericUpDown_ID.Size = new System.Drawing.Size(220, 25);
            this.numericUpDown_ID.TabIndex = 44;
            // 
            // numericUpDown_age
            // 
            this.numericUpDown_age.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown_age.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.numericUpDown_age.Location = new System.Drawing.Point(276, 227);
            this.numericUpDown_age.Name = "numericUpDown_age";
            this.numericUpDown_age.Size = new System.Drawing.Size(143, 29);
            this.numericUpDown_age.TabIndex = 43;
            // 
            // btn_teaAdd
            // 
            this.btn_teaAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(223)))), ((int)(((byte)(163)))));
            this.btn_teaAdd.FlatAppearance.BorderSize = 0;
            this.btn_teaAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_teaAdd.Font = new System.Drawing.Font("微软雅黑", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_teaAdd.ForeColor = System.Drawing.Color.White;
            this.btn_teaAdd.Location = new System.Drawing.Point(811, 20);
            this.btn_teaAdd.Name = "btn_teaAdd";
            this.btn_teaAdd.Size = new System.Drawing.Size(220, 41);
            this.btn_teaAdd.TabIndex = 30;
            this.btn_teaAdd.Text = "点击添加教师";
            this.btn_teaAdd.UseVisualStyleBackColor = false;
            this.btn_teaAdd.Click += new System.EventHandler(this.btn_teaAdd_Click);
            // 
            // textBox_stuS
            // 
            this.textBox_stuS.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_stuS.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_stuS.Location = new System.Drawing.Point(276, 286);
            this.textBox_stuS.Name = "textBox_stuS";
            this.textBox_stuS.Size = new System.Drawing.Size(143, 26);
            this.textBox_stuS.TabIndex = 31;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label9.Location = new System.Drawing.Point(167, 403);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 25);
            this.label9.TabIndex = 40;
            this.label9.Text = "入职部门：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Location = new System.Drawing.Point(199, 164);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 25);
            this.label7.TabIndex = 39;
            this.label7.Text = "性 别：";
            // 
            // textBox_Name
            // 
            this.textBox_Name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_Name.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_Name.Location = new System.Drawing.Point(276, 89);
            this.textBox_Name.Name = "textBox_Name";
            this.textBox_Name.Size = new System.Drawing.Size(143, 26);
            this.textBox_Name.TabIndex = 32;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label8.Location = new System.Drawing.Point(574, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 25);
            this.label8.TabIndex = 36;
            this.label8.Text = "银行卡号：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(198, 286);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 25);
            this.label3.TabIndex = 33;
            this.label3.Text = "学 籍：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(198, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 25);
            this.label6.TabIndex = 35;
            this.label6.Text = "年 龄：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(555, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 25);
            this.label2.TabIndex = 38;
            this.label2.Text = "身份证号码：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(165, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 25);
            this.label5.TabIndex = 34;
            this.label5.Text = "教师编号：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(198, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 25);
            this.label4.TabIndex = 37;
            this.label4.Text = "姓 名：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label10.Location = new System.Drawing.Point(199, 343);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 25);
            this.label10.TabIndex = 40;
            this.label10.Text = "学 历：";
            // 
            // comboBox_edu
            // 
            this.comboBox_edu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_edu.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.comboBox_edu.FormattingEnabled = true;
            this.comboBox_edu.Items.AddRange(new object[] {
            "本科",
            "硕士",
            "博士",
            "院士",
            "其他"});
            this.comboBox_edu.Location = new System.Drawing.Point(276, 342);
            this.comboBox_edu.Name = "comboBox_edu";
            this.comboBox_edu.Size = new System.Drawing.Size(143, 29);
            this.comboBox_edu.TabIndex = 45;
            // 
            // monthCalendar_birthday
            // 
            this.monthCalendar_birthday.Location = new System.Drawing.Point(685, 190);
            this.monthCalendar_birthday.Name = "monthCalendar_birthday";
            this.monthCalendar_birthday.TabIndex = 0;
            this.monthCalendar_birthday.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar_birthday_DateChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label11.Location = new System.Drawing.Point(608, 194);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 25);
            this.label11.TabIndex = 39;
            this.label11.Text = "生 日：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label12.Location = new System.Drawing.Point(575, 34);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(107, 25);
            this.label12.TabIndex = 33;
            this.label12.Text = "授课科目：";
            // 
            // textBox_teaching
            // 
            this.textBox_teaching.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_teaching.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_teaching.Location = new System.Drawing.Point(685, 33);
            this.textBox_teaching.Name = "textBox_teaching";
            this.textBox_teaching.Size = new System.Drawing.Size(220, 26);
            this.textBox_teaching.TabIndex = 31;
            // 
            // panel_center
            // 
            this.panel_center.Controls.Add(this.groupBox2);
            this.panel_center.Controls.Add(this.numericUpDown_No);
            this.panel_center.Controls.Add(this.monthCalendar_birthday);
            this.panel_center.Controls.Add(this.label4);
            this.panel_center.Controls.Add(this.groupBox_gender);
            this.panel_center.Controls.Add(this.label5);
            this.panel_center.Controls.Add(this.comboBox_edu);
            this.panel_center.Controls.Add(this.label2);
            this.panel_center.Controls.Add(this.comboBox_dept);
            this.panel_center.Controls.Add(this.label6);
            this.panel_center.Controls.Add(this.label3);
            this.panel_center.Controls.Add(this.numericUpDown_bankCardNo);
            this.panel_center.Controls.Add(this.label8);
            this.panel_center.Controls.Add(this.numericUpDown_ID);
            this.panel_center.Controls.Add(this.label12);
            this.panel_center.Controls.Add(this.numericUpDown_age);
            this.panel_center.Controls.Add(this.textBox_Name);
            this.panel_center.Controls.Add(this.label7);
            this.panel_center.Controls.Add(this.label10);
            this.panel_center.Controls.Add(this.label_birthday);
            this.panel_center.Controls.Add(this.label16);
            this.panel_center.Controls.Add(this.label11);
            this.panel_center.Controls.Add(this.textBox_teaching);
            this.panel_center.Controls.Add(this.label9);
            this.panel_center.Controls.Add(this.textBox_stuS);
            this.panel_center.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_center.Location = new System.Drawing.Point(0, 44);
            this.panel_center.Name = "panel_center";
            this.panel_center.Size = new System.Drawing.Size(1060, 581);
            this.panel_center.TabIndex = 47;
            // 
            // panel_bottom
            // 
            this.panel_bottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panel_bottom.Controls.Add(this.btn_teaAdd);
            this.panel_bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_bottom.Location = new System.Drawing.Point(0, 625);
            this.panel_bottom.Name = "panel_bottom";
            this.panel_bottom.Size = new System.Drawing.Size(1060, 85);
            this.panel_bottom.TabIndex = 48;
            // 
            // textBox_uName
            // 
            this.textBox_uName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_uName.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_uName.Location = new System.Drawing.Point(94, 42);
            this.textBox_uName.Name = "textBox_uName";
            this.textBox_uName.Size = new System.Drawing.Size(143, 26);
            this.textBox_uName.TabIndex = 31;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label13.Location = new System.Drawing.Point(16, 42);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 25);
            this.label13.TabIndex = 33;
            this.label13.Text = "用户名：";
            // 
            // textBox_uPwd
            // 
            this.textBox_uPwd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_uPwd.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_uPwd.Location = new System.Drawing.Point(341, 43);
            this.textBox_uPwd.Name = "textBox_uPwd";
            this.textBox_uPwd.Size = new System.Drawing.Size(143, 26);
            this.textBox_uPwd.TabIndex = 31;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label14.Location = new System.Drawing.Point(272, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 25);
            this.label14.TabIndex = 33;
            this.label14.Text = "密  码：";
            // 
            // textBox_email
            // 
            this.textBox_email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_email.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_email.Location = new System.Drawing.Point(579, 42);
            this.textBox_email.Name = "textBox_email";
            this.textBox_email.Size = new System.Drawing.Size(143, 26);
            this.textBox_email.TabIndex = 31;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label15.Location = new System.Drawing.Point(510, 42);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(81, 25);
            this.label15.TabIndex = 33;
            this.label15.Text = "邮  箱：";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox_email);
            this.groupBox2.Controls.Add(this.textBox_uName);
            this.groupBox2.Controls.Add(this.textBox_uPwd);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(170, 461);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(735, 102);
            this.groupBox2.TabIndex = 47;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "教师登录信息";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label16.Location = new System.Drawing.Point(608, 401);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(164, 25);
            this.label16.TabIndex = 39;
            this.label16.Text = "您录入的生日是：";
            // 
            // label_birthday
            // 
            this.label_birthday.AutoSize = true;
            this.label_birthday.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_birthday.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label_birthday.Location = new System.Drawing.Point(769, 401);
            this.label_birthday.Name = "label_birthday";
            this.label_birthday.Size = new System.Drawing.Size(116, 25);
            this.label_birthday.TabIndex = 39;
            this.label_birthday.Text = "0000/00/00";
            // 
            // childForm_teaAdd
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1060, 710);
            this.Controls.Add(this.panel_bottom);
            this.Controls.Add(this.panel_center);
            this.Controls.Add(this.panel_top);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "childForm_teaAdd";
            this.Text = "childForm_teaAdd";
            this.Load += new System.EventHandler(this.childForm_teaAdd_Load);
            this.panel_top.ResumeLayout(false);
            this.panel_top.PerformLayout();
            this.groupBox_gender.ResumeLayout(false);
            this.groupBox_gender.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_No)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_bankCardNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_age)).EndInit();
            this.panel_center.ResumeLayout(false);
            this.panel_center.PerformLayout();
            this.panel_bottom.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_top;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox_gender;
        private System.Windows.Forms.RadioButton radioButton_woman;
        private System.Windows.Forms.RadioButton radioButton_man;
        private System.Windows.Forms.ComboBox comboBox_dept;
        private System.Windows.Forms.NumericUpDown numericUpDown_No;
        private System.Windows.Forms.NumericUpDown numericUpDown_bankCardNo;
        private System.Windows.Forms.NumericUpDown numericUpDown_ID;
        private System.Windows.Forms.NumericUpDown numericUpDown_age;
        private System.Windows.Forms.Button btn_teaAdd;
        private System.Windows.Forms.TextBox textBox_stuS;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_Name;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MonthCalendar monthCalendar_birthday;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox_edu;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_teaching;
        private System.Windows.Forms.Panel panel_center;
        private System.Windows.Forms.Panel panel_bottom;
        private System.Windows.Forms.TextBox textBox_email;
        private System.Windows.Forms.TextBox textBox_uPwd;
        private System.Windows.Forms.TextBox textBox_uName;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label_birthday;
        private System.Windows.Forms.Label label16;
    }
}